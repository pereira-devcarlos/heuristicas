import os
import sys
import subprocess


def read_instance(file_path):
    """
    Reads an instance file.
    The expected format is:
    First line: <number_of_nodes> <number_of_edges>
    Subsequent lines: <node_u> <node_v> <weight>
    """
    import networkx as nx

    with open(file_path, 'r') as file:
        # Read the first line to get the number of nodes and edges
        first_line = file.readline().strip().split()
        if not first_line:
            return None

        num_nodes = int(first_line[0])
        num_edges = int(first_line[1])

        G = nx.Graph()
        G.add_nodes_from(range(num_nodes))

        # Parse the remaining lines for the edges
        for line in file:
            parts = line.strip().split()
            if len(parts) >= 3:
                # Can be int or float for weights, using float to be safe
                u = int(parts[0])
                v = int(parts[1])
                weight = float(parts[2])
                G.add_edge(u, v, weight=weight)

        return G

def main():
    if len(sys.argv) < 3:
        print("Usage: python main.py <instance_name> <algorithm> ")
        return

    instance_name = sys.argv[1]
    algorithm = sys.argv[2]

    # Instances are shared with the base implementation.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    instances_dir = os.path.join(base_dir, '..', 'codeBase', 'instancias')
    file_path = os.path.join(instances_dir, instance_name)

    if not os.path.exists(file_path):
        print(f"Instance file not found: {file_path}")
        return

    if algorithm == "brkga":
        # O executável C++ utiliza os operadores originais da biblioteca BRKGA.
        executable = os.path.join(base_dir, "brkga")
        if not os.path.exists(executable):
            print("Compile primeiro: make")
            return
        result = subprocess.run([executable, file_path, *sys.argv[3:]])
        sys.exit(result.returncode)

    print(f"Processing {instance_name} with algorithm '{algorithm}'...")
    instance_data = read_instance(file_path)

    if instance_data is not None:
        print(f"  -> Nodes: {instance_data.number_of_nodes()}, Edges: {instance_data.number_of_edges()}")
        from heuristics import Heuristics

        heuristics = Heuristics(instance_data)

        match algorithm:
            case "construtiva" | "construtivo" | "guloso" | "gulosa":
                heuristics.construtiva()
            case "local":
                heuristics.construtiva()
                heuristics.local()
            case "repair" | "reparar":
                heuristics.construtiva()
                heuristics.repair()
            case 'vnd':
                heuristics.vnd()
            case 'ils':
                heuristics.ils()
            case 'ga' | 'genetico':
                heuristics.genetic_algorithm()
            case _:
                print(f"Unknown algorithm: {algorithm}")

        cost = heuristics.evaluate()

        print("Final cost:", cost)
        print("Number of edges:", len(heuristics.best_solution))
if __name__ == '__main__':
    main()
